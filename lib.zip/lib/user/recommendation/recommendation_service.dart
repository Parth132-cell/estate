import 'package:cloud_firestore/cloud_firestore.dart';

class RecommendationService {
  final _db = FirebaseFirestore.instance;

  Stream<List<Map<String, dynamic>>> recommend({
    required String city,
    required int bhk,
    required double budget,
  }) async* {
    final snap = await _db
        .collection('properties')
        .where('status', isEqualTo: 'approved')
        .get();

    List<Map<String, dynamic>> scored = [];

    for (var doc in snap.docs) {
      final p = doc.data();
      int score = 0;

      if (p['city'] == city) score += 40;
      if (p['bhk'] == bhk) score += 25;

      final price = (p['price'] as num).toDouble();
      if ((price - budget).abs() <= budget * 0.15) {
        score += 20;
      }

      score += 10; // recency bonus (Phase-1 simplification)

      scored.add({'id': doc.id, 'score': score, ...p});
    }

    scored.sort((a, b) => b['score'].compareTo(a['score']));
    yield scored.take(5).toList();
  }
}
