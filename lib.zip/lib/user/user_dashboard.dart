import 'package:estatex_app/user/compare/compare_screen.dart';
import 'package:estatex_app/user/search/property_search_screen.dart';
import 'package:flutter/material.dart';

class UserDashboard extends StatelessWidget {
  const UserDashboard({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Home")),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ElevatedButton(
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const PropertySearchScreen()),
              );
            },
            child: const Text("Search Properties"),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const CompareScreen()),
              );
            },
            child: const Text("Compare Properties"),
          ),
        ],
      ),
    );
  }
}
