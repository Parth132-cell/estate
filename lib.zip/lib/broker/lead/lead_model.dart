import 'package:cloud_firestore/cloud_firestore.dart';

class Lead {
  final String id;
  final String name;
  final String phone;
  final String propertyId;
  final String brokerId;
  final String status;
  final String notes;
  final DateTime? followUpDate;

  const Lead({
    required this.id,
    required this.name,
    required this.phone,
    required this.propertyId,
    required this.brokerId,
    required this.status,
    required this.notes,
    this.followUpDate,
  });

  factory Lead.fromMap(String id, Map<String, dynamic>? map) {
    if (map == null) {
      return Lead(
        id: id,
        name: '',
        phone: '',
        propertyId: '',
        brokerId: '',
        status: 'new',
        notes: '',
        followUpDate: null,
      );
    }

    DateTime? followUp;
    final rawDate = map['followUpDate'];

    if (rawDate is Timestamp) {
      followUp = rawDate.toDate();
    } else if (rawDate is DateTime) {
      followUp = rawDate;
    }

    return Lead(
      id: id,
      name: map['name'] ?? '',
      phone: map['phone'] ?? '',
      propertyId: map['propertyId'] ?? '',
      brokerId: map['brokerId'] ?? '',
      status: map['status'] ?? 'new',
      notes: map['notes'] ?? '',
      followUpDate: followUp,
    );
  }
}
