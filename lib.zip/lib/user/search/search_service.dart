import 'package:cloud_firestore/cloud_firestore.dart';

class SearchService {
  final _db = FirebaseFirestore.instance;

  Stream<QuerySnapshot<Map<String, dynamic>>> searchProperties({
    String? city,
    int? minPrice,
    int? maxPrice,
    int? bhk,
  }) {
    Query<Map<String, dynamic>> query = _db
        .collection('properties')
        .where('status', isEqualTo: 'approved');

    if (city != null && city.isNotEmpty) {
      query = query.where('city', isEqualTo: city);
    }

    if (bhk != null) {
      query = query.where('bhk', isEqualTo: bhk);
    }

    if (minPrice != null) {
      query = query.where('minPrice', isEqualTo: minPrice);
    }
    if (maxPrice != null) {
      query = query.where('maxPrice', isEqualTo: maxPrice);
    }
    return query.snapshots();
  }
}
