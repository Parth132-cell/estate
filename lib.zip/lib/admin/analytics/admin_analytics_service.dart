import 'package:cloud_firestore/cloud_firestore.dart';

class AdminAnalyticsService {
  final _db = FirebaseFirestore.instance;

  /// Fetch all brokers
  Stream<QuerySnapshot<Map<String, dynamic>>> brokers() {
    return _db
        .collection('users')
        .where('role', isEqualTo: 'broker')
        .where('status', isEqualTo: 'approved')
        .snapshots();
  }

  /// Count leads for a broker
  Future<int> leadCount(String brokerId) async {
    final snap = await _db
        .collection('leads')
        .where('brokerId', isEqualTo: brokerId)
        .get();

    return snap.docs.length;
  }
}
