import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import 'property_details_screen.dart';

class PropertyListScreen extends StatelessWidget {
  const PropertyListScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder(
      stream: FirebaseFirestore.instance
          .collection('properties')
          .where('status', isEqualTo: 'approved')
          .snapshots(),
      builder: (context, snapshot) {
        if (!snapshot.hasData) {
          return const Center(child: CircularProgressIndicator());
        }

        final docs = snapshot.data!.docs;

        if (docs.isEmpty) {
          return const Center(child: Text("No properties available"));
        }

        return ListView.builder(
          itemCount: docs.length,
          itemBuilder: (context, index) {
            final doc = docs[index];
            final data = doc.data();

            return Card(
              margin: const EdgeInsets.all(8),
              child: ListTile(
                title: Text(data['title']),
                subtitle: Text("${data['city']} • ₹${data['price']}"),
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => PropertyDetailsScreen(propertyId: doc.id),
                    ),
                  );
                },
              ),
            );
          },
        );
      },
    );
  }
}
