import 'package:estatex_app/co-broker/co_broker_services.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../auth/auth_provider.dart';

class CoBrokerRequestsScreen extends ConsumerWidget {
  const CoBrokerRequestsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final broker = ref.watch(authProvider)!;

    return Scaffold(
      appBar: AppBar(title: const Text("Co-Broker Requests")),
      body: StreamBuilder(
        stream: CoBrokerService().receivedRequests(broker.uid),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }

          final docs = snapshot.data!.docs;

          if (docs.isEmpty) {
            return const Center(child: Text("No requests"));
          }

          return ListView.builder(
            itemCount: docs.length,
            itemBuilder: (context, index) {
              final doc = docs[index];
              final data = doc.data();

              return Card(
                child: ListTile(
                  title: Text("Property: ${data['propertyId']}"),
                  subtitle: Text("Commission: ${data['commissionSplit']}%"),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      IconButton(
                        icon: const Icon(Icons.check),
                        onPressed: () =>
                            CoBrokerService().updateStatus(doc.id, 'accepted'),
                      ),
                      IconButton(
                        icon: const Icon(Icons.close),
                        onPressed: () =>
                            CoBrokerService().updateStatus(doc.id, 'rejected'),
                      ),
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
