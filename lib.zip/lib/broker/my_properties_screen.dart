import 'package:estatex_app/services/property_services.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../auth/auth_provider.dart';

class MyPropertiesScreen extends ConsumerWidget {
  const MyPropertiesScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final user = ref.watch(authProvider)!;

    return Scaffold(
      appBar: AppBar(title: const Text("My Properties")),
      body: StreamBuilder(
        stream: PropertyService().brokerProperties(user.uid),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }

          final docs = snapshot.data!.docs;

          if (docs.isEmpty) {
            return const Center(child: Text("No properties added"));
          }

          return ListView.builder(
            itemCount: docs.length,
            itemBuilder: (context, index) {
              final data = docs[index].data() as Map<String, dynamic>;
              return ListTile(
                title: Text(data['title']),
                subtitle: Text(data['location']),
                trailing: Chip(
                  label: Text(
                    data['verified'] ? "Verified" : "Pending",
                    style: const TextStyle(color: Colors.white),
                  ),
                  backgroundColor: data['verified']
                      ? Colors.green
                      : Colors.orange,
                ),
              );
            },
          );
        },
      ),
    );
  }
}
