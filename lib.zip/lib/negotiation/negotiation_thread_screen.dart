import 'package:estatex_app/negotiation/negotiation_services.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class NegotiationThreadScreen extends StatelessWidget {
  final String leadId;
  final String role; // buyer | broker
  final String propertyId;
  final String brokerId;
  final String buyerId;

  const NegotiationThreadScreen({
    super.key,
    required this.leadId,
    required this.role,
    required this.propertyId,
    required this.brokerId,
    required this.buyerId,
  });

  @override
  Widget build(BuildContext context) {
    final ctrl = TextEditingController();

    return Scaffold(
      appBar: AppBar(title: const Text("Negotiation")),
      body: Column(
        children: [
          /// 🔁 NEGOTIATION THREAD
          Expanded(
            child: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
              stream: NegotiationService().thread(leadId),
              builder: (context, snapshot) {
                if (!snapshot.hasData) {
                  return const Center(child: CircularProgressIndicator());
                }

                final msgs = snapshot.data!.docs;

                if (msgs.isEmpty) {
                  return const Center(child: Text("No offers yet"));
                }

                // 🔥 LATEST OFFER (CRITICAL FOR ACCEPT)
                final latestOffer =
                    (msgs.last.data()['offerAmount'] as num?)?.toDouble() ??
                    0.0;

                return Column(
                  children: [
                    Expanded(
                      child: ListView.builder(
                        itemCount: msgs.length,
                        itemBuilder: (context, index) {
                          final data = msgs[index].data();
                          final isMine = data['senderRole'] == role;

                          return ListTile(
                            title: Text(
                              "₹${data['offerAmount']}",
                              textAlign: isMine
                                  ? TextAlign.right
                                  : TextAlign.left,
                            ),
                            subtitle: Text(data['senderRole']),
                          );
                        },
                      ),
                    ),

                    /// ✅ ACCEPT OFFER (BROKER ONLY)
                    if (role == 'broker')
                      Padding(
                        padding: const EdgeInsets.all(8),
                        child: ElevatedButton(
                          onPressed: () async {
                            // 1️⃣ CREATE DEAL
                            await FirebaseFirestore.instance
                                .collection('deals')
                                .add({
                                  'leadId': leadId,
                                  'propertyId': propertyId,
                                  'brokerId': brokerId,
                                  'buyerId': buyerId,
                                  'dealAmount': latestOffer,
                                  'commissionPercent': 2,
                                  'status': 'pending',
                                  'createdAt': FieldValue.serverTimestamp(),
                                });

                            // 2️⃣ CLOSE NEGOTIATION
                            await FirebaseFirestore.instance
                                .collection('leads')
                                .doc(leadId)
                                .update({
                                  'status': 'accepted',
                                  'activeNegotiation': false,
                                });

                            // 3️⃣ EXIT
                            Navigator.pop(context);
                          },
                          child: const Text("Accept Offer"),
                        ),
                      ),
                  ],
                );
              },
            ),
          ),

          /// ➕ SEND COUNTER OFFER
          Padding(
            padding: const EdgeInsets.all(8),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: ctrl,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(
                      hintText: "Counter offer",
                    ),
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.send),
                  onPressed: () {
                    final amount = double.tryParse(ctrl.text);
                    if (amount == null) return;

                    NegotiationService().sendOffer(
                      leadId: leadId,
                      senderRole: role,
                      offerAmount: amount,
                    );
                    ctrl.clear();
                  },
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
