import 'package:estatex_app/admin/pending_broker_screen.dart';
import 'package:estatex_app/app/app_home_screen.dart';
import 'package:estatex_app/user/user_dashboard.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'auth/auth_provider.dart';
import 'auth/login_screen.dart';
import 'admin/admin_dashboard.dart';
import 'broker/broker_dashboard.dart';

class MyRouter extends ConsumerWidget {
  const MyRouter({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final user = ref.watch(authProvider);

    Widget home;

    if (user == null) {
      home = LoginScreen();
    } else if (user.role == 'admin') {
      home = AdminDashboard();
    } else if (user.role == 'broker') {
      if (user.approved == 'pending') {
        home = const PendingBrokersScreen();
      } else {
        home = const BrokerDashboard();
      }
    } else {
      home = AppHomeScreen();
    }

    return MaterialApp(debugShowCheckedModeBanner: false, home: home);
  }
}
