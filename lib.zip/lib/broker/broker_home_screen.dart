import 'package:estatex_app/broker/lead/broker_leads_screen.dart';
import 'package:estatex_app/broker/my_properties_screen.dart';
import 'package:flutter/material.dart';
import 'broker_menu_card.dart';

class BrokerHomeScreen extends StatelessWidget {
  const BrokerHomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Broker Dashboard")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: GridView.count(
          crossAxisCount: 2,
          mainAxisSpacing: 16,
          crossAxisSpacing: 16,
          children: [
            BrokerMenuCard(
              icon: Icons.home_work,
              title: "My Properties",
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const MyPropertiesScreen()),
                );
              },
            ),
            BrokerMenuCard(
              icon: Icons.people,
              title: "Leads",
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const BrokerLeadsScreen()),
                );
              },
            ),
            BrokerMenuCard(
              icon: Icons.assignment_turned_in,
              title: "Deals",
              onTap: () {
                // later
              },
            ),
            BrokerMenuCard(
              icon: Icons.account_circle,
              title: "Profile",
              onTap: () {
                // later
              },
            ),
          ],
        ),
      ),
    );
  }
}
