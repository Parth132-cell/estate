import 'package:estatex_app/auth/register_screen.dart';
import 'package:estatex_app/models/user_models.dart';
import 'package:estatex_app/services/auth_services.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'auth_provider.dart';

class LoginScreen extends ConsumerWidget {
  final emailCtrl = TextEditingController();
  final passCtrl = TextEditingController();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Scaffold(
      appBar: AppBar(title: const Text("Login")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(
              controller: emailCtrl,
              decoration: const InputDecoration(labelText: "Email"),
            ),
            TextField(
              controller: passCtrl,
              obscureText: true,
              decoration: const InputDecoration(labelText: "Password"),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () async {
                try {
                  final user = await AuthServices().login(
                    emailCtrl.text.trim(),
                    passCtrl.text.trim(),
                  );

                  if (user == null) return;

                  final snap = await AuthServices().getUser(user.uid);

                  if (!snap.exists) {
                    throw "User data not found. Please contact support.";
                  }

                  final appUser = AppUser.fromMap(
                    snap.data() as Map<String, dynamic>,
                    user.uid,
                  );

                  // 🔥 This triggers navigation automatically
                  ref.read(authProvider.notifier).state = appUser;
                } catch (e) {
                  ScaffoldMessenger.of(
                    context,
                  ).showSnackBar(SnackBar(content: Text(e.toString())));
                }
              },
              child: const Text("Login"),
            ),

            SizedBox(height: 16),
            TextButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const RegisterScreen()),
                );
              },
              child: const Text("Create Account"),
            ),
          ],
        ),
      ),
    );
  }
}
