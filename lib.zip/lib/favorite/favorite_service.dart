import 'package:cloud_firestore/cloud_firestore.dart';

class FavoriteService {
  final _db = FirebaseFirestore.instance;

  Future<void> toggleFavorite({
    required String userId,
    required String propertyId,
  }) async {
    final snap = await _db
        .collection('saved_properties')
        .where('userId', isEqualTo: userId)
        .where('propertyId', isEqualTo: propertyId)
        .limit(1)
        .get();

    if (snap.docs.isNotEmpty) {
      await _db.collection('saved_properties').doc(snap.docs.first.id).delete();
    } else {
      await _db.collection('saved_properties').add({
        'userId': userId,
        'propertyId': propertyId,
        'createdAt': FieldValue.serverTimestamp(),
      });
    }
  }

  Stream<bool> isSaved({required String userId, required String propertyId}) {
    return _db
        .collection('saved_properties')
        .where('userId', isEqualTo: userId)
        .where('propertyId', isEqualTo: propertyId)
        .snapshots()
        .map((snap) => snap.docs.isNotEmpty);
  }

  Stream<QuerySnapshot<Map<String, dynamic>>> savedForUser(String userId) {
    return _db
        .collection('saved_properties')
        .where('userId', isEqualTo: userId)
        .orderBy('createdAt', descending: true)
        .snapshots();
  }
}
