import 'package:estatex_app/broker/lead/lead_details_screen.dart';
import 'package:estatex_app/broker/lead/lead_services.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../auth/auth_provider.dart';

class BrokerLeadsScreen extends ConsumerWidget {
  const BrokerLeadsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final broker = ref.watch(authProvider)!;

    return Scaffold(
      appBar: AppBar(title: const Text("Leads")),
      body: StreamBuilder(
        stream: LeadService().brokerLeads(broker.uid),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }

          final docs = snapshot.data!.docs;

          if (docs.isEmpty) {
            return const Center(child: Text("No leads yet"));
          }

          return ListView.builder(
            itemCount: docs.length,
            itemBuilder: (context, index) {
              final doc = docs[index];
              final data = doc.data();

              return Card(
                margin: const EdgeInsets.all(8),
                child: ListTile(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) =>
                            LeadDetailScreen(leadId: doc.id, leadData: data),
                      ),
                    );
                  },
                  title: Text(data['name']),
                  subtitle: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text("📞 ${data['phone']}"),
                      Text("Status: ${data['status']}"),
                    ],
                  ),
                  trailing: PopupMenuButton<String>(
                    onSelected: (value) {
                      LeadService().updateLeadStatus(
                        leadId: doc.id,
                        status: value,
                        notes: data['notes'] ?? '',
                      );
                    },
                    itemBuilder: (context) => const [
                      PopupMenuItem(value: 'new', child: Text("New")),
                      PopupMenuItem(
                        value: 'contacted',
                        child: Text("Contacted"),
                      ),
                      PopupMenuItem(
                        value: 'site_visit',
                        child: Text("Site Visit"),
                      ),
                      PopupMenuItem(value: 'closed', child: Text("Closed")),
                      PopupMenuItem(value: 'lost', child: Text("Lost")),
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
