import 'package:estatex_app/negotiation/negotiation_services.dart';
import 'package:flutter/material.dart';

class MakeOfferScreen extends StatefulWidget {
  final String leadId;

  const MakeOfferScreen({super.key, required this.leadId});

  @override
  State<MakeOfferScreen> createState() => _MakeOfferScreenState();
}

class _MakeOfferScreenState extends State<MakeOfferScreen> {
  final offerCtrl = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Make Offer")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(
              controller: offerCtrl,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: "Offer Amount"),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () async {
                await NegotiationService().sendOffer(
                  leadId: widget.leadId,
                  senderRole: 'buyer',
                  offerAmount: double.parse(offerCtrl.text),
                );
                Navigator.pop(context);
              },
              child: const Text("Submit Offer"),
            ),
          ],
        ),
      ),
    );
  }
}
