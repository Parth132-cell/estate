import 'package:cloud_firestore/cloud_firestore.dart';

class PriceHistoryService {
  final _db = FirebaseFirestore.instance;

  Stream<QuerySnapshot<Map<String, dynamic>>> historyForArea(String area) {
    return _db
        .collection('area_price_history')
        .where('area', isEqualTo: area)
        .orderBy('year')
        .snapshots();
  }
}
