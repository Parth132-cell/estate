import 'package:estatex_app/co-broker/co_broker_services.dart';
import 'package:flutter/material.dart';

class RequestCoBrokerScreen extends StatefulWidget {
  final String propertyId;
  final String listingBrokerId;

  const RequestCoBrokerScreen({
    super.key,
    required this.propertyId,
    required this.listingBrokerId,
  });

  @override
  State<RequestCoBrokerScreen> createState() => _RequestCoBrokerScreenState();
}

class _RequestCoBrokerScreenState extends State<RequestCoBrokerScreen> {
  final coBrokerIdCtrl = TextEditingController();
  double split = 50;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Invite Co-Broker")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(
              controller: coBrokerIdCtrl,
              decoration: const InputDecoration(
                labelText: "Co-Broker ID / Email",
              ),
            ),
            Slider(
              value: split,
              min: 10,
              max: 90,
              divisions: 8,
              label: "${split.toInt()}%",
              onChanged: (v) => setState(() => split = v),
            ),
            ElevatedButton(
              onPressed: () async {
                await CoBrokerService().sendRequest(
                  propertyId: widget.propertyId,
                  listingBrokerId: widget.listingBrokerId,
                  coBrokerId: coBrokerIdCtrl.text,
                  commissionSplit: split,
                );
                Navigator.pop(context);
              },
              child: const Text("Send Request"),
            ),
          ],
        ),
      ),
    );
  }
}
