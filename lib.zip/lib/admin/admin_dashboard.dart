import 'package:estatex_app/admin/analytics/broker_performance_screen.dart';
import 'package:estatex_app/admin/escrow/admin_escrow_screen.dart';
import 'package:estatex_app/admin/pending_broker_screen.dart';
import 'package:flutter/material.dart';

import 'verify_properties_screen.dart';

class AdminDashboard extends StatelessWidget {
  const AdminDashboard({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Admin Dashboard")),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          ElevatedButton(
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const PendingBrokersScreen()),
              );
            },
            child: const Text("Approve Brokers"),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => const VerifyPropertiesScreen(),
                ),
              );
            },
            child: const Text("Verify Properties"),
          ),

          SizedBox(height: 16),
          ElevatedButton(
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => const BrokerPerformanceScreen(),
                ),
              );
            },
            child: const Text("Broker Performance"),
          ),
          SizedBox(height: 16),
          ElevatedButton(
            child: const Text("Manage Escrow"),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const AdminEscrowScreen()),
              );
            },
          ),
        ],
      ),
    );
  }
}
