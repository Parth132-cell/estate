import 'package:cloud_firestore/cloud_firestore.dart';

class LiveTourServices {
  final _db = FirebaseFirestore.instance;

  Future<void> scheduleTour({
    required String propertyId,
    required String brokerId,
    required DateTime dateTime,
  }) async {
    await _db.collection('live_tours').add({
      'propertyId': propertyId,
      'brokerId': brokerId,
      'scheduledAt': Timestamp.fromDate(dateTime),
      'status': 'scheduled',
      'createdAt': FieldValue.serverTimestamp(),
    });
  }

  Stream<QuerySnapshot<Map<String, dynamic>>> toursForProperty(
    String propertyId,
  ) {
    return _db
        .collection('live_tours')
        .where('propertyId', isEqualTo: propertyId)
        .orderBy('scheduledAt')
        .snapshots();
  }
}
