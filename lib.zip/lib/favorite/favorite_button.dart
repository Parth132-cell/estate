import 'package:flutter/material.dart';
import 'favorite_service.dart';

class FavoriteButton extends StatelessWidget {
  final String userId;
  final String propertyId;

  const FavoriteButton({
    super.key,
    required this.userId,
    required this.propertyId,
  });

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<bool>(
      stream: FavoriteService().isSaved(userId: userId, propertyId: propertyId),
      builder: (context, snapshot) {
        final isSaved = snapshot.data ?? false;

        return IconButton(
          icon: Icon(
            isSaved ? Icons.favorite : Icons.favorite_border,
            color: isSaved ? Colors.red : Colors.grey,
          ),
          onPressed: () async {
            await FavoriteService().toggleFavorite(
              userId: userId,
              propertyId: propertyId,
            );

            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text(
                  isSaved ? "Removed from saved" : "Saved to favorites",
                ),
                duration: const Duration(seconds: 1),
              ),
            );
          },
        );
      },
    );
  }
}
