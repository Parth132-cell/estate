import 'package:flutter/material.dart';

class JoinTourScreen extends StatelessWidget {
  final DateTime scheduledAt;

  const JoinTourScreen({super.key, required this.scheduledAt});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Live Video Tour")),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.videocam, size: 80),
            const SizedBox(height: 20),
            Text(
              "Live tour scheduled at:\n$scheduledAt",
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text(
                      "WebRTC video room will launch here (Phase-2)",
                    ),
                  ),
                );
              },
              child: const Text("Join Live Tour"),
            ),
          ],
        ),
      ),
    );
  }
}
