class Property {
  final String id;
  final String title;
  final String location;
  final double price;
  final String brokerId;
  final bool verified;

  Property({
    required this.id,
    required this.title,
    required this.location,
    required this.price,
    required this.brokerId,
    required this.verified,
  });

  factory Property.fromMap(Map<String, dynamic> map, String id) {
    return Property(
      id: id,
      title: map['title'] ?? '',
      location: map['location'] ?? '',
      price: (map['price'] is num) ? (map['price'] as num).toDouble() : 0.0,
      brokerId: map['brokerId'] ?? '',
      verified: map['verified'] ?? false,
    );
  }
}
