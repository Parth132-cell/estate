import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'compare_controller.dart';

class CompareScreen extends ConsumerWidget {
  const CompareScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final properties = ref.watch(compareProvider);

    if (properties.length < 2) {
      return Scaffold(
        appBar: AppBar(title: const Text("Compare Properties")),
        body: const Center(
          child: Text("Select at least 2 properties to compare"),
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text("Property Comparison"),
        actions: [
          IconButton(
            icon: const Icon(Icons.clear),
            onPressed: () => ref.read(compareProvider.notifier).clear(),
          ),
        ],
      ),
      body: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(
          children: properties.map((p) {
            return Container(
              width: 250,
              margin: const EdgeInsets.all(8),
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                border: Border.all(),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    p['title'],
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 10),
                  Text("City: ${p['city']}"),
                  Text("Price: ₹${p['price']}"),
                  Text("BHK: ${p['bhk']}"),
                  Text("Status: ${p['status']}"),
                ],
              ),
            );
          }).toList(),
        ),
      ),
    );
  }
}
