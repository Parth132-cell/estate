class CoBrokerRequest {
  final String id;
  final String propertyId;
  final String listingBrokerId;
  final String coBrokerId;
  final double commissionSplit; // percentage for co-broker
  final String status; // pending / accepted / rejected

  const CoBrokerRequest({
    required this.id,
    required this.propertyId,
    required this.listingBrokerId,
    required this.coBrokerId,
    required this.commissionSplit,
    required this.status,
  });

  factory CoBrokerRequest.fromMap(String id, Map<String, dynamic>? map) {
    if (map == null) {
      return CoBrokerRequest(
        id: id,
        propertyId: '',
        listingBrokerId: '',
        coBrokerId: '',
        commissionSplit: 0.0,
        status: 'pending',
      );
    }

    return CoBrokerRequest(
      id: id,
      propertyId: map['propertyId'] ?? '',
      listingBrokerId: map['listingBrokerId'] ?? '',
      coBrokerId: map['coBrokerId'] ?? '',
      commissionSplit: (map['commissionSplit'] is num)
          ? (map['commissionSplit'] as num).toDouble()
          : 0.0,
      status: map['status'] ?? 'pending',
    );
  }
}
