import 'package:estatex_app/user/ar/ar_services.dart';
import 'package:flutter/material.dart';

class ARPreviewScreen extends StatelessWidget {
  final String propertyTitle;
  final String modelUrl; // future 3D model URL

  const ARPreviewScreen({
    super.key,
    required this.propertyTitle,
    required this.modelUrl,
  });

  @override
  Widget build(BuildContext context) {
    final arService = ARService();

    return Scaffold(
      appBar: AppBar(title: const Text("AR Preview")),
      body: Center(
        child: arService.isARSupported()
            ? Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.view_in_ar, size: 80),
                  const SizedBox(height: 20),
                  Text(
                    "AR Preview for\n$propertyTitle",
                    textAlign: TextAlign.center,
                    style: const TextStyle(fontSize: 18),
                  ),
                  const SizedBox(height: 20),
                  ElevatedButton(
                    onPressed: () {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text(
                            "AR Preview will launch using ARCore / ARKit in Phase-2",
                          ),
                        ),
                      );
                    },
                    child: const Text("Launch AR Preview"),
                  ),
                ],
              )
            : const Text(
                "AR not supported on this device",
                textAlign: TextAlign.center,
              ),
      ),
    );
  }
}
