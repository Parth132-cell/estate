import 'package:estatex_app/auth/auth_provider.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class AddPropertyScreen extends ConsumerStatefulWidget {
  const AddPropertyScreen({super.key});

  @override
  ConsumerState<AddPropertyScreen> createState() => _AddPropertyScreenState();
}

class _AddPropertyScreenState extends ConsumerState<AddPropertyScreen> {
  final titleCtrl = TextEditingController();
  final cityCtrl = TextEditingController();
  final priceCtrl = TextEditingController();
  int bhk = 2;

  bool loading = false;

  Future<void> saveProperty() async {
    final user = ref.read(authProvider)!;

    setState(() => loading = true);

    await FirebaseFirestore.instance.collection('properties').add({
      'title': titleCtrl.text,
      'city': cityCtrl.text,
      'price': int.parse(priceCtrl.text),
      'bhk': bhk,

      'addedByRole': user.role,
      'addedById': user.uid,

      'brokerId': user.role == 'broker' ? user.uid : null,
      'ownerId': user.role == 'user' ? user.uid : null,

      'status': 'pending',
      'createdAt': FieldValue.serverTimestamp(),
    });

    setState(() => loading = false);

    Navigator.pop(context);

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text("Property submitted. Waiting for admin verification."),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final user = ref.watch(authProvider)!;

    return Scaffold(
      appBar: AppBar(
        title: Text(
          user.role == 'broker'
              ? "Add Property (Broker)"
              : "Add Property (Owner)",
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: ListView(
          children: [
            TextField(
              controller: titleCtrl,
              decoration: const InputDecoration(labelText: "Property Title"),
            ),
            TextField(
              controller: cityCtrl,
              decoration: const InputDecoration(labelText: "City"),
            ),
            TextField(
              controller: priceCtrl,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: "Price"),
            ),

            const SizedBox(height: 16),

            DropdownButtonFormField<int>(
              value: bhk,
              decoration: const InputDecoration(labelText: "BHK"),
              items: const [
                DropdownMenuItem(value: 1, child: Text("1 BHK")),
                DropdownMenuItem(value: 2, child: Text("2 BHK")),
                DropdownMenuItem(value: 3, child: Text("3 BHK")),
                DropdownMenuItem(value: 4, child: Text("4 BHK")),
              ],
              onChanged: (v) => setState(() => bhk = v!),
            ),

            const SizedBox(height: 30),

            ElevatedButton(
              onPressed: loading ? null : saveProperty,
              child: const Text("Submit Property"),
            ),
          ],
        ),
      ),
    );
  }
}
