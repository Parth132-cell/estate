import 'package:estatex_app/services/admin_services.dart';
import 'package:flutter/material.dart';

class PendingBrokersScreen extends StatelessWidget {
  const PendingBrokersScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Pending Brokers")),
      body: StreamBuilder(
        stream: AdminService().pendingBrokers(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }

          final docs = snapshot.data!.docs;

          if (docs.isEmpty) {
            return const Center(child: Text("No pending brokers"));
          }

          return ListView.builder(
            itemCount: docs.length,
            itemBuilder: (context, index) {
              final doc = docs[index];
              final data = doc.data() as Map<String, dynamic>;

              return Card(
                child: ListTile(
                  title: Text(data['email']),
                  trailing: ElevatedButton(
                    onPressed: () async {
                      await AdminService().approveBroker(doc.id);
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text("Broker Approved")),
                      );
                    },
                    child: const Text("Approve"),
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
