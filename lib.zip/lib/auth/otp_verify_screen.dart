import 'package:estatex_app/navigation/main_navigation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'auth_controller.dart';

class OtpVerifyScreen extends ConsumerWidget {
  final String verificationId;

  const OtpVerifyScreen({super.key, required this.verificationId});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final otpCtrl = TextEditingController();

    return Scaffold(
      appBar: AppBar(title: const Text("Verify OTP")),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          children: [
            TextField(
              controller: otpCtrl,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: "Enter OTP"),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              child: const Text("Verify"),
              onPressed: () async {
                await AuthController().verifyOtp(
                  verificationId: verificationId,
                  otp: otpCtrl.text,
                  ref: ref,
                );

                Navigator.pushAndRemoveUntil(
                  context,
                  MaterialPageRoute(builder: (_) => const MainNavigation()),
                  (_) => false,
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
