import 'package:estatex_app/payments/escrow_service.dart';
import 'package:estatex_app/payments/escrow_status_screen.dart';
import 'package:estatex_app/reviews/add_review_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import '../auth/auth_provider.dart';

class DealDetailsScreen extends ConsumerWidget {
  final String dealId;
  final Map<String, dynamic> dealData;

  const DealDetailsScreen({
    super.key,
    required this.dealId,
    required this.dealData,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final user = ref.watch(authProvider)!;

    final bool isBuyer = dealData['buyerId'] == user.uid;
    final bool isAccepted = dealData['status'] == 'accepted';
    final bool isCompleted = dealData['status'] == 'completed';

    return Scaffold(
      appBar: AppBar(title: const Text("Deal Details")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text("Deal Amount: ₹${dealData['dealAmount']}"),
            Text("Status: ${dealData['status']}"),
            const SizedBox(height: 20),

            /// 🔐 BUYER TOKEN PAYMENT (ESCROW)
            if (isBuyer && isAccepted)
              StreamBuilder(
                stream: FirebaseFirestore.instance
                    .collection('escrow')
                    .where('dealId', isEqualTo: dealId)
                    .limit(1)
                    .snapshots(),
                builder: (context, snapshot) {
                  final alreadyPaid =
                      snapshot.hasData && snapshot.data!.docs.isNotEmpty;

                  if (alreadyPaid) {
                    return ElevatedButton(
                      child: const Text("View Escrow Status"),
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => EscrowStatusScreen(dealId: dealId),
                          ),
                        );
                      },
                    );
                  }

                  return ElevatedButton(
                    child: const Text("Pay Token (10% Escrow)"),
                    onPressed: () async {
                      await EscrowService().createEscrow(
                        dealId: dealId,
                        buyerId: user.uid,
                        amount: (dealData['dealAmount'] as num) * 0.1,
                      );

                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text("Token amount held securely in escrow"),
                        ),
                      );
                    },
                  );
                },
              ),

            /// ⭐ LEAVE REVIEW (BUYER ONLY, AFTER DEAL COMPLETION)
            if (isBuyer && isCompleted)
              ElevatedButton(
                child: const Text("Leave Review"),
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => AddReviewScreen(
                        dealId: dealId,
                        propertyId: dealData['propertyId'],
                        brokerId: dealData['brokerId'],
                        reviewerId: user.uid,
                      ),
                    ),
                  );
                },
              ),

            /// Explanation for other users
            if (!isBuyer)
              const Text(
                "Only the buyer can pay the token amount.",
                style: TextStyle(color: Colors.grey),
              ),
          ],
        ),
      ),
    );
  }
}
