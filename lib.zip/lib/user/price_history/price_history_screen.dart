import 'package:flutter/material.dart';
import 'price_history_service.dart';

class PriceHistoryScreen extends StatelessWidget {
  final String area;

  const PriceHistoryScreen({super.key, required this.area});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Price History - $area")),
      body: StreamBuilder(
        stream: PriceHistoryService().historyForArea(area),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }

          final docs = snapshot.data!.docs;

          if (docs.isEmpty) {
            return const Center(
              child: Text(
                "Price history data will be available soon.\n"
                "Based on registered sale transactions.",
                textAlign: TextAlign.center,
              ),
            );
          }

          return ListView.builder(
            itemCount: docs.length,
            itemBuilder: (context, index) {
              final data = docs[index].data();
              return ListTile(
                leading: const Icon(Icons.trending_up),
                title: Text("Year: ${data['year']}"),
                subtitle: Text("Avg Price: ₹${data['averagePrice']}"),
              );
            },
          );
        },
      ),
    );
  }
}
