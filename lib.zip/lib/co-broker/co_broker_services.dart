import 'package:cloud_firestore/cloud_firestore.dart';

class CoBrokerService {
  final _db = FirebaseFirestore.instance;

  /// Send request
  Future<void> sendRequest({
    required String propertyId,
    required String listingBrokerId,
    required String coBrokerId,
    required double commissionSplit,
  }) async {
    await _db.collection('co_broker_requests').add({
      'propertyId': propertyId,
      'listingBrokerId': listingBrokerId,
      'coBrokerId': coBrokerId,
      'commissionSplit': commissionSplit,
      'status': 'pending',
      'createdAt': FieldValue.serverTimestamp(),
    });
  }

  /// Requests received by broker
  Stream<QuerySnapshot<Map<String, dynamic>>> receivedRequests(
    String brokerId,
  ) {
    return _db
        .collection('co_broker_requests')
        .where('coBrokerId', isEqualTo: brokerId)
        .where('status', isEqualTo: 'pending')
        .snapshots();
  }

  /// Accept / Reject
  Future<void> updateStatus(String requestId, String status) async {
    await _db.collection('co_broker_requests').doc(requestId).update({
      'status': status,
    });
  }
}
