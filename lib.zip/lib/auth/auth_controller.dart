import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_riverpod/legacy.dart';

import 'auth_state.dart';

final authProvider = StateProvider<AppUser?>((ref) => null);

class AuthController {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  /// 📲 SEND OTP
  Future<void> sendOtp({
    required String phone,
    required Function(String verificationId) onCodeSent,
    required Function(String error) onError,
  }) async {
    await _auth.verifyPhoneNumber(
      phoneNumber: phone,
      timeout: const Duration(seconds: 60),

      /// ✅ AUTO VERIFICATION (Android)
      verificationCompleted: (PhoneAuthCredential credential) async {
        await _auth.signInWithCredential(credential);
      },

      /// ❌ ERROR HANDLING
      verificationFailed: (FirebaseAuthException e) {
        onError(e.message ?? "OTP verification failed");
      },

      /// ✅ OTP SENT
      codeSent: (String verificationId, int? resendToken) {
        onCodeSent(verificationId);
      },

      codeAutoRetrievalTimeout: (_) {},
    );
  }

  /// 🔐 VERIFY OTP
  Future<void> verifyOtp({
    required String verificationId,
    required String otp,
    required WidgetRef ref,
  }) async {
    final credential = PhoneAuthProvider.credential(
      verificationId: verificationId,
      smsCode: otp,
    );

    final result = await _auth.signInWithCredential(credential);
    final user = result.user;

    if (user == null) return;

    final uid = user.uid;
    final phone = user.phoneNumber ?? '';

    final userRef = _db.collection('users').doc(uid);
    final doc = await userRef.get();

    /// 👤 CREATE USER IF NOT EXISTS
    if (!doc.exists) {
      await userRef.set({
        'phone': phone,
        'profileType': 'individual',
        'canUploadProperty': false,
        'canHostLiveTour': false,
        'createdAt': FieldValue.serverTimestamp(),
      });
    }

    /// 📦 LOAD USER INTO APP STATE
    final userSnap = await userRef.get();
    ref.read(authProvider.notifier).state = AppUser.fromMap(
      uid,
      userSnap.data(),
    );
  }
}
