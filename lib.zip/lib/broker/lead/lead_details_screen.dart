import 'package:estatex_app/broker/lead/lead_services.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class LeadDetailScreen extends StatefulWidget {
  final String leadId;
  final Map<String, dynamic> leadData;

  const LeadDetailScreen({
    super.key,
    required this.leadId,
    required this.leadData,
  });

  @override
  State<LeadDetailScreen> createState() => _LeadDetailScreenState();
}

class _LeadDetailScreenState extends State<LeadDetailScreen> {
  late TextEditingController notesCtrl;
  late String status;
  DateTime? followUpDate;

  @override
  void initState() {
    super.initState();
    notesCtrl = TextEditingController(text: widget.leadData['notes'] ?? '');
    status = widget.leadData['status'];
    followUpDate = widget.leadData['followUpDate'] != null
        ? (widget.leadData['followUpDate'] as Timestamp).toDate()
        : null;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Lead Details")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text("Name: ${widget.leadData['name']}"),
            Text("Phone: ${widget.leadData['phone']}"),
            const SizedBox(height: 20),

            DropdownButtonFormField<String>(
              value: status,
              decoration: const InputDecoration(labelText: "Status"),
              items: const [
                DropdownMenuItem(value: 'new', child: Text("New")),
                DropdownMenuItem(value: 'contacted', child: Text("Contacted")),
                DropdownMenuItem(
                  value: 'site_visit',
                  child: Text("Site Visit"),
                ),
                DropdownMenuItem(value: 'closed', child: Text("Closed")),
                DropdownMenuItem(value: 'lost', child: Text("Lost")),
              ],
              onChanged: (value) {
                setState(() => status = value!);
              },
            ),

            const SizedBox(height: 15),

            TextField(
              controller: notesCtrl,
              maxLines: 4,
              decoration: const InputDecoration(labelText: "Notes"),
            ),

            const SizedBox(height: 15),

            ElevatedButton(
              onPressed: () async {
                final picked = await showDatePicker(
                  context: context,
                  firstDate: DateTime.now(),
                  lastDate: DateTime(2100),
                  initialDate: followUpDate ?? DateTime.now(),
                );
                if (picked != null) {
                  setState(() => followUpDate = picked);
                }
              },
              child: Text(
                followUpDate == null
                    ? "Set Follow-up Date"
                    : "Follow-up: ${followUpDate!.toLocal().toString().split(' ')[0]}",
              ),
            ),

            const SizedBox(height: 30),

            ElevatedButton(
              onPressed: () async {
                await LeadService().updateLeadStatus(
                  leadId: widget.leadId,
                  status: status,
                  notes: notesCtrl.text,
                  followUpDate: followUpDate,
                );

                Navigator.pop(context);
              },
              child: const Text("Save Changes"),
            ),
          ],
        ),
      ),
    );
  }
}
