import 'package:cloud_firestore/cloud_firestore.dart';

class NegotiationService {
  final _db = FirebaseFirestore.instance;

  /// Send offer / counter-offer
  Future<void> sendOffer({
    required String leadId,
    required String senderRole,
    required double offerAmount,
  }) async {
    await _db
        .collection('negotiations')
        .doc(leadId)
        .collection('messages')
        .add({
          'leadId': leadId,
          'senderRole': senderRole,
          'offerAmount': offerAmount,
          'createdAt': FieldValue.serverTimestamp(),
        });
  }

  /// Negotiation history
  Stream<QuerySnapshot<Map<String, dynamic>>> thread(String leadId) {
    return _db
        .collection('negotiations')
        .doc(leadId)
        .collection('messages')
        .orderBy('createdAt')
        .snapshots();
  }
}
