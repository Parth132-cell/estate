import 'package:estatex_app/models/user_models.dart';

import 'package:flutter_riverpod/legacy.dart';

final authProvider = StateProvider<AppUser?>((ref) => null);
