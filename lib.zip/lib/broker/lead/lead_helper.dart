import 'package:cloud_firestore/cloud_firestore.dart';

Future<String> getOrCreateLead({
  required String propertyId,
  required String brokerId,
  required String buyerId,
}) async {
  final db = FirebaseFirestore.instance;

  // 🔍 Check if lead already exists
  final existing = await db
      .collection('leads')
      .where('propertyId', isEqualTo: propertyId)
      .where('buyerId', isEqualTo: buyerId)
      .limit(1)
      .get();

  if (existing.docs.isNotEmpty) {
    return existing.docs.first.id;
  }

  // ➕ Create new lead
  final doc = await db.collection('leads').add({
    'propertyId': propertyId,
    'brokerId': brokerId,
    'buyerId': buyerId,
    'status': 'new',
    'activeNegotiation': false,
    'createdAt': FieldValue.serverTimestamp(),
  });

  return doc.id;
}
