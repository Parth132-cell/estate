import 'package:estatex_app/live_tour/live_tour_services.dart';
import 'package:flutter/material.dart';

class ScheduleTourScreen extends StatefulWidget {
  final String propertyId;
  final String brokerId;

  const ScheduleTourScreen({
    super.key,
    required this.propertyId,
    required this.brokerId,
  });

  @override
  State<ScheduleTourScreen> createState() => _ScheduleTourScreenState();
}

class _ScheduleTourScreenState extends State<ScheduleTourScreen> {
  DateTime? selectedDateTime;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Schedule Live Tour")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            ElevatedButton(
              onPressed: () async {
                final date = await showDatePicker(
                  context: context,
                  firstDate: DateTime.now(),
                  lastDate: DateTime(2100),
                  initialDate: DateTime.now(),
                );
                if (date == null) return;

                final time = await showTimePicker(
                  context: context,
                  initialTime: TimeOfDay.now(),
                );
                if (time == null) return;

                setState(() {
                  selectedDateTime = DateTime(
                    date.year,
                    date.month,
                    date.day,
                    time.hour,
                    time.minute,
                  );
                });
              },
              child: const Text("Pick Date & Time"),
            ),

            const SizedBox(height: 20),

            ElevatedButton(
              onPressed: selectedDateTime == null
                  ? null
                  : () async {
                      await LiveTourServices().scheduleTour(
                        propertyId: widget.propertyId,
                        brokerId: widget.brokerId,
                        dateTime: selectedDateTime!,
                      );

                      Navigator.pop(context);
                    },
              child: const Text("Schedule Tour"),
            ),
          ],
        ),
      ),
    );
  }
}
