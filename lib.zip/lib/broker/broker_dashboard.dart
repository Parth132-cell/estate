import 'package:flutter/material.dart';
import 'broker_home_screen.dart';

class BrokerDashboard extends StatelessWidget {
  const BrokerDashboard({super.key});

  @override
  Widget build(BuildContext context) {
    return const BrokerHomeScreen();
  }
}
