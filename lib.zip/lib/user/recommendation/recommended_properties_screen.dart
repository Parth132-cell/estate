import 'package:estatex_app/user/property/property_details_screen.dart';
import 'package:flutter/material.dart';
import 'recommendation_service.dart';

class RecommendedPropertiesScreen extends StatelessWidget {
  final String city;
  final int bhk;
  final double budget;

  const RecommendedPropertiesScreen({
    super.key,
    required this.city,
    required this.bhk,
    required this.budget,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Recommended for You")),
      body: StreamBuilder(
        stream: RecommendationService().recommend(
          city: city,
          bhk: bhk,
          budget: budget,
        ),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }

          final properties = snapshot.data!;

          if (properties.isEmpty) {
            return const Center(child: Text("No recommendations available"));
          }

          return ListView.builder(
            itemCount: properties.length,
            itemBuilder: (context, index) {
              final p = properties[index];
              return Card(
                margin: const EdgeInsets.all(8),
                child: ListTile(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) =>
                            PropertyDetailsScreen(propertyId: p['id']),
                      ),
                    );
                  },

                  title: Text(p['title']),
                  subtitle: Text(
                    "₹${p['price']} • ${p['city']} • Score: ${p['score']}",
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
