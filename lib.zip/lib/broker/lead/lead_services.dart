import 'package:cloud_firestore/cloud_firestore.dart';

class LeadService {
  final _db = FirebaseFirestore.instance;

  /// Fetch leads for broker
  Stream<QuerySnapshot<Map<String, dynamic>>> brokerLeads(String brokerId) {
    return _db
        .collection('leads')
        .where('brokerId', isEqualTo: brokerId)
        .orderBy('createdAt', descending: true)
        .snapshots();
  }

  /// Update lead status
  Future<void> updateLeadStatus({
    required String leadId,
    required String status,
    required String notes,
    DateTime? followUpDate,
  }) async {
    await _db.collection('leads').doc(leadId).update({
      'status': status,
      'notes': notes,
      'followUpDate': followUpDate != null
          ? Timestamp.fromDate(followUpDate)
          : null,
    });
  }
}
