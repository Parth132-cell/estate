import 'package:estatex_app/user/compare/compare_controller.dart';
import 'package:estatex_app/user/property/property_details_screen.dart';
import 'package:estatex_app/user/recommendation/recommended_properties_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'search_service.dart';

class PropertySearchScreen extends ConsumerStatefulWidget {
  const PropertySearchScreen({super.key});

  @override
  ConsumerState<PropertySearchScreen> createState() =>
      _PropertySearchScreenState();
}

class _PropertySearchScreenState extends ConsumerState<PropertySearchScreen> {
  String city = '';
  int? bhk;
  int? minPrice;
  int? maxPrice;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Search Properties")),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(8),
            child: TextField(
              decoration: const InputDecoration(labelText: "City"),
              onChanged: (v) => city = v,
            ),
          ),

          Padding(
            padding: const EdgeInsets.all(8),
            child: DropdownButtonFormField<int>(
              decoration: const InputDecoration(labelText: "BHK"),
              items: const [
                DropdownMenuItem(value: 1, child: Text("1 BHK")),
                DropdownMenuItem(value: 2, child: Text("2 BHK")),
                DropdownMenuItem(value: 3, child: Text("3 BHK")),
              ],
              onChanged: (v) => bhk = v,
            ),
          ),

          ElevatedButton(
            onPressed: () {
              setState(() {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => RecommendedPropertiesScreen(
                      city: city,
                      bhk: bhk ?? 2,
                      budget: (minPrice ?? 0).toDouble(),
                    ),
                  ),
                );
              });
            },
            child: const Text("Search"),
          ),

          Expanded(
            child: StreamBuilder(
              stream: SearchService().searchProperties(
                city: city,
                bhk: bhk,
                minPrice: minPrice,
                maxPrice: maxPrice,
              ),
              builder: (context, snapshot) {
                if (!snapshot.hasData) {
                  return const Center(child: CircularProgressIndicator());
                }

                final docs = snapshot.data!.docs;

                if (docs.isEmpty) {
                  return const Center(child: Text("No results"));
                }

                return ListView.builder(
                  itemCount: docs.length,
                  itemBuilder: (context, index) {
                    final doc = docs[index];
                    final data = doc.data();

                    return Card(
                      margin: const EdgeInsets.symmetric(
                        horizontal: 8,
                        vertical: 4,
                      ),
                      child: ListTile(
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => PropertyDetailsScreen(
                                propertyId: docs[index].id,
                              ),
                            ),
                          );
                        },

                        title: Text(data['title'] ?? ''),
                        subtitle: Text(
                          "${data['city'] ?? ''} • ₹${data['price'] ?? 0}",
                        ),

                        // 🔥 COMPARE BUTTON ADDED
                        trailing: IconButton(
                          icon: const Icon(Icons.compare),
                          onPressed: () {
                            ref.read(compareProvider.notifier).addProperty({
                              'id': doc.id,
                              ...data,
                            });

                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(
                                content: Text("Added to comparison"),
                              ),
                            );
                          },
                        ),
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
