import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../auth/auth_provider.dart';
import '../user/property/property_list_screen.dart';
import '../property/add_property/add_property_screen.dart';

class AppHomeScreen extends ConsumerWidget {
  const AppHomeScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final user = ref.watch(authProvider)!;

    return Scaffold(
      appBar: AppBar(
        title: const Text("EstateX"),
        actions: [
          if (user.role == 'broker' || user.role == 'user')
            IconButton(
              icon: const Icon(Icons.add_home),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => AddPropertyScreen()),
                );
              },
            ),
        ],
      ),
      body: const PropertyListScreen(),
    );
  }
}
