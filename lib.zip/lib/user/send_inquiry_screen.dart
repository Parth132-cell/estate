import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class SendEnquiryScreen extends StatefulWidget {
  final String propertyId;
  final String brokerId;

  const SendEnquiryScreen({
    super.key,
    required this.propertyId,
    required this.brokerId,
  });

  @override
  State<SendEnquiryScreen> createState() => _SendEnquiryScreenState();
}

class _SendEnquiryScreenState extends State<SendEnquiryScreen> {
  final nameCtrl = TextEditingController();
  final phoneCtrl = TextEditingController();

  bool loading = false;

  Future<void> submitEnquiry() async {
    setState(() => loading = true);

    await FirebaseFirestore.instance.collection('leads').add({
      'name': nameCtrl.text,
      'phone': phoneCtrl.text,
      'propertyId': widget.propertyId,
      'brokerId': widget.brokerId,
      'status': 'new',
      'notes': '',
      'createdAt': FieldValue.serverTimestamp(),
    });

    setState(() => loading = false);

    ScaffoldMessenger.of(
      context,
    ).showSnackBar(const SnackBar(content: Text("Enquiry sent successfully")));

    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Contact Broker")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(
              controller: nameCtrl,
              decoration: const InputDecoration(labelText: "Your Name"),
            ),
            TextField(
              controller: phoneCtrl,
              decoration: const InputDecoration(labelText: "Phone Number"),
              keyboardType: TextInputType.phone,
            ),
            const SizedBox(height: 30),
            ElevatedButton(
              onPressed: loading ? null : submitEnquiry,
              child: const Text("Send Enquiry"),
            ),
          ],
        ),
      ),
    );
  }
}
