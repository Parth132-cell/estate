class AreaPriceHistory {
  final String area;
  final int year;
  final double averagePrice;

  AreaPriceHistory({
    required this.area,
    required this.year,
    required this.averagePrice,
  });

  factory AreaPriceHistory.fromMap(Map<String, dynamic> map) {
    return AreaPriceHistory(
      area: map['area'],
      year: map['year'],
      averagePrice: (map['averagePrice'] as num).toDouble(),
    );
  }
}
