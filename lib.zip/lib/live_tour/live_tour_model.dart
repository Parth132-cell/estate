import 'package:cloud_firestore/cloud_firestore.dart';

class LiveTour {
  final String id;
  final String propertyId;
  final String brokerId;
  final DateTime scheduledAt;
  final String status; // scheduled | live | ended

  const LiveTour({
    required this.id,
    required this.propertyId,
    required this.brokerId,
    required this.scheduledAt,
    required this.status,
  });

  factory LiveTour.fromMap(String id, Map<String, dynamic>? map) {
    if (map == null) {
      return LiveTour(
        id: id,
        propertyId: '',
        brokerId: '',
        scheduledAt: DateTime.fromMillisecondsSinceEpoch(0),
        status: 'scheduled',
      );
    }

    // Safe DateTime parsing
    DateTime scheduled;
    final rawDate = map['scheduledAt'];

    if (rawDate is Timestamp) {
      scheduled = rawDate.toDate();
    } else if (rawDate is DateTime) {
      scheduled = rawDate;
    } else {
      scheduled = DateTime.fromMillisecondsSinceEpoch(0);
    }

    return LiveTour(
      id: id,
      propertyId: map['propertyId'] ?? '',
      brokerId: map['brokerId'] ?? '',
      scheduledAt: scheduled,
      status: map['status'] ?? 'scheduled',
    );
  }
}
