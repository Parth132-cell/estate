import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'join_tour_screen.dart';

class LiveTourListWidget extends StatelessWidget {
  final String propertyId;

  const LiveTourListWidget({super.key, required this.propertyId});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder(
      stream: FirebaseFirestore.instance
          .collection('live_tours')
          .where('propertyId', isEqualTo: propertyId)
          .orderBy('scheduledAt')
          .snapshots(),
      builder: (context, snapshot) {
        if (!snapshot.hasData) {
          return const CircularProgressIndicator();
        }

        final tours = snapshot.data!.docs;

        if (tours.isEmpty) {
          return const Text("No live tours scheduled yet.");
        }

        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              "Live Video Tours",
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),

            ...tours.map((doc) {
              final data = doc.data();
              final DateTime scheduled = (data['scheduledAt'] as Timestamp)
                  .toDate();

              final bool isLive =
                  DateTime.now().isAfter(scheduled) &&
                  DateTime.now().isBefore(
                    scheduled.add(const Duration(hours: 1)),
                  );

              return Card(
                child: ListTile(
                  leading: Icon(
                    isLive ? Icons.videocam : Icons.schedule,
                    color: isLive ? Colors.red : Colors.blue,
                  ),
                  title: Text(
                    isLive ? "Live Now" : "Scheduled: ${scheduled.toLocal()}",
                  ),
                  trailing: ElevatedButton(
                    onPressed: isLive || DateTime.now().isAfter(scheduled)
                        ? () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) =>
                                    JoinTourScreen(scheduledAt: scheduled),
                              ),
                            );
                          }
                        : null,
                    child: const Text("Join"),
                  ),
                ),
              );
            }).toList(),
          ],
        );
      },
    );
  }
}
