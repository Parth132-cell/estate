import 'package:cloud_firestore/cloud_firestore.dart';

class NegotiationMessage {
  final String id;
  final String leadId;
  final String senderRole; // buyer | broker
  final double offerAmount;
  final DateTime createdAt;

  const NegotiationMessage({
    required this.id,
    required this.leadId,
    required this.senderRole,
    required this.offerAmount,
    required this.createdAt,
  });

  factory NegotiationMessage.fromMap(String id, Map<String, dynamic>? map) {
    if (map == null) {
      return NegotiationMessage(
        id: id,
        leadId: '',
        senderRole: 'buyer',
        offerAmount: 0.0,
        createdAt: DateTime.fromMillisecondsSinceEpoch(0),
      );
    }

    // Safe DateTime parsing
    DateTime created;
    final rawDate = map['createdAt'];

    if (rawDate is Timestamp) {
      created = rawDate.toDate();
    } else if (rawDate is DateTime) {
      created = rawDate;
    } else {
      created = DateTime.fromMillisecondsSinceEpoch(0);
    }

    return NegotiationMessage(
      id: id,
      leadId: map['leadId'] ?? '',
      senderRole: map['senderRole'] ?? 'buyer',
      offerAmount: (map['offerAmount'] is num)
          ? (map['offerAmount'] as num).toDouble()
          : 0.0,
      createdAt: created,
    );
  }
}
