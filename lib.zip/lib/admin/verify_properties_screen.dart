import 'package:estatex_app/services/admin_services.dart';
import 'package:flutter/material.dart';

class VerifyPropertiesScreen extends StatelessWidget {
  const VerifyPropertiesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Verify Properties")),
      body: StreamBuilder(
        stream: AdminService().pendingProperties(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }

          final docs = snapshot.data!.docs;

          if (docs.isEmpty) {
            return const Center(child: Text("No pending properties"));
          }

          return ListView.builder(
            itemCount: docs.length,
            itemBuilder: (context, index) {
              final doc = docs[index];
              final data = doc.data() as Map<String, dynamic>;

              return Card(
                child: ListTile(
                  title: Text(data['title']),
                  subtitle: Text(data['location']),
                  trailing: ElevatedButton(
                    onPressed: () async {
                      await AdminService().verifyProperty(doc.id);
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text("Property Verified")),
                      );
                    },
                    child: const Text("Verify"),
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
