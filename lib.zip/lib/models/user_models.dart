class AppUser {
  final String uid;
  final String email;
  final String role;
  final bool approved;

  AppUser({
    required this.uid,
    required this.email,
    required this.role,
    required this.approved,
  });

  factory AppUser.fromMap(Map<String, dynamic> map, String uid) {
    return AppUser(
      uid: uid,
      email: map['email'] ?? '',
      role: map['role'] ?? 'user',
      approved: map['approved'] ?? false,
    );
  }
}
