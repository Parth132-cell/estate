import 'package:estatex_app/auth/auth_provider.dart';
import 'package:estatex_app/broker/lead/lead_helper.dart';
import 'package:estatex_app/live_tour/join_tour_screen.dart';
import 'package:estatex_app/live_tour/live_tour_list_widget.dart';
import 'package:estatex_app/live_tour/live_tour_services.dart';
import 'package:estatex_app/live_tour/schedule_tour_screen.dart';
import 'package:estatex_app/negotiation/negotiation_thread_screen.dart';
import 'package:estatex_app/reviews/rating_summary_widget.dart';
import 'package:estatex_app/user/send_inquiry_screen.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../ar/ar_preview_screen.dart';
import '../price_history/price_history_screen.dart';
// import '../negotiation/make_offer_screen.dart';
// import '../co_broker/request_cobroker_screen.dart';

class PropertyDetailsScreen extends ConsumerWidget {
  final String propertyId;

  const PropertyDetailsScreen({super.key, required this.propertyId});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final currentUser = ref.watch(authProvider)!;

    return Scaffold(
      appBar: AppBar(title: const Text("Property Details")),
      body: StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
        stream: FirebaseFirestore.instance
            .collection('properties')
            .doc(propertyId)
            .snapshots(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }

          final data = snapshot.data!.data();
          if (data == null) {
            return const Center(child: Text("Property not found"));
          }

          // 🧱 STEP B1 — IDENTIFY RELATIONSHIP
          final bool isOwner = data['addedById'] == currentUser.uid;

          final bool isListingBroker =
              currentUser.role == 'broker' &&
              data['brokerId'] == currentUser.uid;

          final bool isBroker = currentUser.role == 'broker';
          final bool isBuyer = currentUser.role == 'user';
          final bool isAdmin = currentUser.role == 'admin';

          return SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                /// TITLE + VERIFIED BADGE
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        data['title'] ?? '',
                        style: const TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    if (data['status'] == 'approved')
                      const Chip(
                        label: Text(
                          "Verified",
                          style: TextStyle(color: Colors.white),
                        ),
                        backgroundColor: Colors.green,
                      ),
                  ],
                ),

                const SizedBox(height: 10),
                Text("📍 ${data['city'] ?? ''}"),
                Text("🏠 ${data['bhk'] ?? 0} BHK"),
                Text(
                  "💰 ₹${data['price'] ?? 0}",
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 8),

                /// ⭐ BROKER TRUST / RATING
                RatingSummaryWidget(brokerId: data['brokerId']),

                const Divider(height: 30),

                /// VIEW IN AR
                ElevatedButton.icon(
                  icon: const Icon(Icons.view_in_ar),
                  label: const Text("View in AR"),
                  onPressed: () {
                    final modelUrl = data['arModelUrl'] ?? '';

                    if (modelUrl.isEmpty) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text("AR model not available")),
                      );
                      return;
                    }

                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => ARPreviewScreen(
                          propertyTitle: data['title'] ?? '',
                          modelUrl: modelUrl,
                        ),
                      ),
                    );
                  },
                ),

                /// PRICE HISTORY
                ElevatedButton.icon(
                  icon: const Icon(Icons.trending_up),
                  label: const Text("Area Price History"),
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => PriceHistoryScreen(area: data['city']),
                      ),
                    );
                  },
                ),
                const Divider(height: 30),

                LiveTourListWidget(propertyId: propertyId),

                /// 🧱 STEP B3 — ACTION GROUP
                const Divider(),
                const Text(
                  "Actions",
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 8),

                /// 🔹 BUYER ACTIONS
                if (isBuyer && !isOwner) ...[
                  ElevatedButton.icon(
                    icon: const Icon(Icons.phone),
                    label: const Text("Contact Broker"),
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => SendEnquiryScreen(
                            propertyId: propertyId,
                            brokerId: data['brokerId'],
                          ),
                        ),
                      );
                    },
                  ),

                  ElevatedButton.icon(
                    icon: const Icon(Icons.handshake),
                    label: const Text("Negotiate / Make Offer"),
                    onPressed: () async {
                      final leadId = await getOrCreateLead(
                        propertyId: propertyId,
                        brokerId: data['brokerId'],
                        buyerId: currentUser.uid,
                      );
                      await FirebaseFirestore.instance
                          .collection('leads')
                          .doc(leadId)
                          .update({
                            'status': 'negotiating',
                            'activeNegotiation': true,
                          });

                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => NegotiationThreadScreen(
                            leadId: leadId,
                            role: 'buyer',
                            propertyId: propertyId,
                            brokerId: data['brokerId'],
                            buyerId: currentUser.uid,
                          ),
                        ),
                      );
                    },
                  ),
                ],

                /// 🔹 LISTING BROKER ACTIONS
                if (isListingBroker) ...[
                  ElevatedButton.icon(
                    icon: const Icon(Icons.schedule),
                    label: const Text("Schedule Live Tour"),
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => ScheduleTourScreen(
                            propertyId: propertyId,
                            brokerId: currentUser.uid,
                          ),
                        ),
                      );
                    },
                  ),

                  ElevatedButton.icon(
                    icon: const Icon(Icons.group_add),
                    label: const Text("Invite Co-Broker"),
                    onPressed: () {
                      // Navigator.push(
                      //   context,
                      //   MaterialPageRoute(
                      //     builder: (_) => RequestCoBrokerScreen(
                      //       propertyId: propertyId,
                      //       listingBrokerId: currentUser.uid,
                      //     ),
                      //   ),
                      // );
                    },
                  ),
                ],

                /// 🔹 OTHER BROKER ACTION
                if (isBroker && !isListingBroker) ...[
                  ElevatedButton.icon(
                    icon: const Icon(Icons.group),
                    label: const Text("Request Co-Broker Access"),
                    onPressed: () {
                      // Navigator.push(
                      //   context,
                      //   MaterialPageRoute(
                      //     builder: (_) => RequestCoBrokerScreen(
                      //       propertyId: propertyId,
                      //       listingBrokerId: data['brokerId'],
                      //     ),
                      //   ),
                      // );
                    },
                  ),
                ],

                /// 🔹 ADMIN ACTIONS
                if (isAdmin) ...[
                  ElevatedButton.icon(
                    icon: const Icon(Icons.verified),
                    label: const Text("Approve Property"),
                    onPressed: () async {
                      await FirebaseFirestore.instance
                          .collection('properties')
                          .doc(propertyId)
                          .update({'status': 'approved'});
                    },
                  ),
                ],

                /// 🔴 LIVE TOUR (BUYER SIDE JOIN)
                if (isBuyer)
                  StreamBuilder<QuerySnapshot>(
                    stream: LiveTourServices().toursForProperty(propertyId),
                    builder: (context, tourSnapshot) {
                      if (tourSnapshot.hasData &&
                          tourSnapshot.data!.docs.isNotEmpty) {
                        final tourData =
                            tourSnapshot.data!.docs.first.data()
                                as Map<String, dynamic>;

                        final scheduledAt =
                            (tourData['scheduledAt'] as Timestamp).toDate();

                        return ElevatedButton.icon(
                          icon: const Icon(Icons.videocam),
                          label: const Text("Join Live Tour"),
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) =>
                                    JoinTourScreen(scheduledAt: scheduledAt),
                              ),
                            );
                          },
                        );
                      }
                      return const SizedBox.shrink();
                    },
                  ),
              ],
            ),
          );
        },
      ),
    );
  }
}
