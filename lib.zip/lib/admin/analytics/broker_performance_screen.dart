import 'package:flutter/material.dart';
import 'admin_analytics_service.dart';

class BrokerPerformanceScreen extends StatelessWidget {
  const BrokerPerformanceScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Broker Performance")),
      body: StreamBuilder(
        stream: AdminAnalyticsService().brokers(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }

          final brokers = snapshot.data!.docs;

          if (brokers.isEmpty) {
            return const Center(child: Text("No brokers found"));
          }

          return ListView.builder(
            itemCount: brokers.length,
            itemBuilder: (context, index) {
              final broker = brokers[index];
              final data = broker.data();

              return FutureBuilder<int>(
                future: AdminAnalyticsService().leadCount(broker.id),
                builder: (context, leadSnap) {
                  final leads = leadSnap.hasData ? leadSnap.data! : 0;

                  return Card(
                    margin: const EdgeInsets.all(8),
                    child: ListTile(
                      title: Text(data['email']),
                      subtitle: Text("Leads handled: $leads"),
                      trailing: Icon(
                        leads > 5 ? Icons.trending_up : Icons.trending_flat,
                        color: leads > 5 ? Colors.green : Colors.orange,
                      ),
                    ),
                  );
                },
              );
            },
          );
        },
      ),
    );
  }
}
