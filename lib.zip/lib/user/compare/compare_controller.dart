import 'package:flutter_riverpod/legacy.dart';

final compareProvider =
    StateNotifierProvider<CompareController, List<Map<String, dynamic>>>(
      (ref) => CompareController(),
    );

class CompareController extends StateNotifier<List<Map<String, dynamic>>> {
  CompareController() : super([]);

  void addProperty(Map<String, dynamic> property) {
    if (state.length >= 3) return;
    if (state.any((p) => p['id'] == property['id'])) return;
    state = [...state, property];
  }

  void removeProperty(String id) {
    state = state.where((p) => p['id'] != id).toList();
  }

  void clear() {
    state = [];
  }
}
